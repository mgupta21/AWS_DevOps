<?php
	# The below is a deliberate error incorporated into this application to test DevOps Lab 2 custom resources.
	writeMESSAGEAccordingToSpecifications();
?>
